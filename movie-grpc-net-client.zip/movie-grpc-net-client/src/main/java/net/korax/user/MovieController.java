package net.korax.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MovieController {
	
	@Autowired
	private MovieService client;
	
	@GetMapping("/movies")
	public ResponseEntity<List<MovieResponse>> getMovies() {
		List<MovieResponse> content = client.getMovies(0, 10);
		return ResponseEntity.ok(content);
	}
	
	@GetMapping("/movies/{id}")
	public ResponseEntity<MovieResponse> getMovie(@PathVariable int id) {
		return ResponseEntity.ok().build();
	}
}
