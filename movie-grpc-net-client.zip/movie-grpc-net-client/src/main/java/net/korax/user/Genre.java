package net.korax.user;

public enum Genre {
	ACTION, DRAMA, HORROR, COMEDY
}
