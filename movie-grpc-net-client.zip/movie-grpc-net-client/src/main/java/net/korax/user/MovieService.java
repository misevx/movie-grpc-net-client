package net.korax.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ivanfranchin.movieserver.movie.model.MovieProto;
import com.ivanfranchin.movieserver.movie.model.MovieProto.Movie;
import com.ivanfranchin.movieserver.movie.model.MovieServerGrpc;

import net.devh.boot.grpc.client.inject.GrpcClient;

@Service
public class MovieService {
	@GrpcClient("movie-grpc-server")
    MovieServerGrpc.MovieServerBlockingStub stub;
	
	public List<MovieResponse> getMovies(int offset, int size) {
        MovieProto.GetMoviesRequest getMoviesRequest = MovieProto.GetMoviesRequest.newBuilder()
                .setOffset(offset)
                .setSize(size)
                .build();
        Iterator<MovieProto.Movie> movieIterator = stub.getMovies(getMoviesRequest);

        List<MovieResponse> movieResponses = new ArrayList<>();
        movieIterator.forEachRemaining(movie -> movieResponses.add(toMovieResponse(movie)));
        return movieResponses;
    }

    private MovieResponse toMovieResponse(Movie movie) {
    	return new MovieResponse(movie.getImdbId(), movie.getTitle(), movie.getYear(), movie.getGenre().name());
	}

	public MovieResponse getMovie(String imdbId) {
        MovieProto.GetMovieRequest getMovieRequest = MovieProto.GetMovieRequest.newBuilder()
                .setImdbId(imdbId)
                .build();
        MovieProto.Movie movie = stub.getMovie(getMovieRequest);
        return toMovieResponse(movie);
    }
}
