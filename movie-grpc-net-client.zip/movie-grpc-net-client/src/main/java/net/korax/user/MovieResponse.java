package net.korax.user;

public record MovieResponse(String imdbId, String title, Integer year, String genre) {
	
}
